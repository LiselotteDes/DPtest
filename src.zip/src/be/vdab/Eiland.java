package be.vdab;

import java.util.ArrayList;
import java.util.List;

public enum Eiland {
    INSTANCE;
    List<Inwoner> inwoners = new ArrayList<>();
    List<Vulkaan> vulkanen = new ArrayList<>();
//    Vulkaan vulkaan = new Vulkaan();
    
    public void addInwoner(Inwoner inwoner) {
        inwoners.add(inwoner);
    }
    public void addVulkaan(Vulkaan vulkaan) {
        vulkanen.add(vulkaan);
    }
    public List<Inwoner> getInwoners() {
        return inwoners;
    }
    public List<Vulkaan> getVulkanen() {
        return vulkanen;
    }    
}
